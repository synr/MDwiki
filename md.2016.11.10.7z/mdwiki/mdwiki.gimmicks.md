#Gimmicks
##大概有哪些功能
- Fork me on GitHub - Ribbon：ForkMeOnGitHub 標籤顯示。
- 放 YouTube 進來： ``youtube.com`` or ``youtu.be`` 都支援。
- 做特定關鍵字提示：
Note、Hint、Attention、Warning 後面接半形的 ``:`` 或 ``!``，整個文章區塊底色會變色。
詳細效果可以看 [測試 Gimmicks - Alerts](#!test/test.gimmicks.md#Alerts)
- GitHub Gists
- Facebook 按讚
- Twitter
- Google Maps
- UML Diagrams via yUML.me：插入流程圖製作平台的圖
那應該是一個用文字指令，就能產流程圖的一種網站。
- Math：顯示數學公式
- Disqus：社群留言板
- Chart：配合表格，再用文字指令的方式寫下，呈現各種統計圖。


##詳細寫法可參考官方 Gimmicks 說明
- [MDwiki - \[Gimmicks\] Markdown based wiki done 100% on the client via javascript](http://dynalon.github.io/mdwiki/#!gimmicks.md)。

----

##測試使用
- 詳見 [測試 Gimmicks](#!test/test.gimmicks.md)