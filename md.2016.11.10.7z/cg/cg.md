﻿#魔力寶貝 2016.06.30 改版後開放的新地圖 露畢恩島
##前往望海村
- [【攻略】主線任務- 騷亂之島I-露畢恩的商船(露畢恩島通行權) @魔力寶貝 哈啦板 - 巴哈姆特](http://forum.gamer.com.tw/C.php?bsn=02577&snA=158254&tnum=4)
  - 解任資格限制：開啟者稱號，戰鬥系40等以上，生產系50等以上。
  - 隊長不能解過這個任務：
解過的人物無法再接，需要沒解過的人物當隊長帶頭解任。
  - 需打小王，不到百等。45、55 等。
  - 路上怪很肥 血大概(?) 2000 上下。
  - 解完道具可交易、丟地，之後聖村坐船身上不用有道具。
  - 解任過程紀念錄影：[１](https://drive.google.com/file/d/0B_b1e3AASsaLLVFjckxiMEVNbTQ/preview)、[２](https://drive.google.com/file/d/0B_b1e3AASsaLNVVSRDYyVlNHTnc/preview)、[３](https://drive.google.com/file/d/0B_b1e3AASsaLN0VXNHQtWmpxbmc/preview)

##孤峰城記點
- [【心得】「露畢恩島」探勘心得集中串（孤峰城記點：騷亂之島Ⅱ失蹤的商人） @魔力寶貝 哈啦板 - 巴哈姆特](http://forum.gamer.com.tw/C.php?bsn=02577&snA=158251&tnum=14)
  - 可以從望海村傳送石，直接花錢傳過來這個城。
  - 記點任務難在收集八個道具。難遇難掉，怪會高連擊，血 1500 (?)上下。
不用打王。
當天打不完，下次可以再從聖村坐船過來繼續解。
道具沒丟掉就不用重新拿。
  - 類似法蘭成的存在
有新的租屋系統，與法蘭的租屋物品內容自動相通。
但只能跟其中一方打契約。
    - 逛逛這個城的新租屋系統：[紀念錄影](https://drive.google.com/file/d/0B_b1e3AASsaLMFpSVXJMeDdvYTQ/preview)
  - 解任過程：[後半「打到八個道具後結束任務」紀念錄影](https://drive.google.com/file/d/0B_b1e3AASsaLbV9qME1IdnAxTU0/preview)
  - 解完也有送道具。
可丟地、交易。

----

##孤峰城周邊村莊路線
[![.](https://trello-attachments.s3.amazonaws.com/5783d8e69b3fce2d52f94f9e/1240x1826/9cc8f762f3229aa500545d5dabd73802/d8ec3759947e33fa65dc91f1dbaeab8e.JPG "新地圖")](https://trello-attachments.s3.amazonaws.com/5783d8e69b3fce2d52f94f9e/1240x1826/9cc8f762f3229aa500545d5dabd73802/d8ec3759947e33fa65dc91f1dbaeab8e.JPG)

- [【情報】露畢恩島(翠森村側) @魔力寶貝 哈啦板 - 巴哈姆特](http://forum.gamer.com.tw/Co.php?bsn=02577&sn=952810)
[![.](https://trello-attachments.s3.amazonaws.com/5783d8e69b3fce2d52f94f9e/834x1298/38dee5fdba021b6043e91ecdf024f34c/f00b16d10b6e656f70e8c03d8120365b.JPG)](https://trello-attachments.s3.amazonaws.com/5783d8e69b3fce2d52f94f9e/834x1298/38dee5fdba021b6043e91ecdf024f34c/f00b16d10b6e656f70e8c03d8120365b.JPG)
[![.](https://trello-attachments.s3.amazonaws.com/5783d8e69b3fce2d52f94f9e/935x696/8c0bc829b3fe144f8e5a6e39a43826c6/031f99966af044829473dbfe7b2f0836.JPG)](https://trello-attachments.s3.amazonaws.com/5783d8e69b3fce2d52f94f9e/935x696/8c0bc829b3fe144f8e5a6e39a43826c6/031f99966af044829473dbfe7b2f0836.JPG)
  - 記點紀念錄影：[點我收看](https://drive.google.com/file/d/0B_b1e3AASsaLeENnQk5XZkFyQkk/preview)
- [【攻略】露畢恩島(雪見村側) @魔力寶貝 哈啦板 - 巴哈姆特](http://forum.gamer.com.tw/Co.php?bsn=02577&sn=952809)
[![.](https://trello-attachments.s3.amazonaws.com/5783d8e69b3fce2d52f94f9e/1140x1189/c3e80edb92e2c52abb16a48634e06048/cc0e4f143c9176c220afbd5f65610567.JPG "點我放大")](https://trello-attachments.s3.amazonaws.com/5783d8e69b3fce2d52f94f9e/1140x1189/c3e80edb92e2c52abb16a48634e06048/cc0e4f143c9176c220afbd5f65610567.JPG)
[![.](https://trello-attachments.s3.amazonaws.com/5783d8e69b3fce2d52f94f9e/1128x798/2a2027d551ebe0de3e78be0e250be832/e56d52aa096b966407418330a86ede20.JPG "點我放大")](https://trello-attachments.s3.amazonaws.com/5783d8e69b3fce2d52f94f9e/1128x798/2a2027d551ebe0de3e78be0e250be832/e56d52aa096b966407418330a86ede20.JPG)
  - 記點紀念錄影：[點我收看](https://drive.google.com/file/d/0B_b1e3AASsaLbjJUM3RPX0ZpUnM/preview)
錄到一半硬碟滿了卻沒發現，所以後面影片斷尾XD
- [【情報】露畢恩島(迷底村側) @魔力寶貝 哈啦板 - 巴哈姆特](http://forum.gamer.com.tw/C.php?bsn=02577&snA=158333&tnum=1)
[![.](https://trello-attachments.s3.amazonaws.com/5783d8e69b3fce2d52f94f9e/1426x1024/1d49176d14681f9448eb262aa3f1bbfb/470ca6a2d9892fa7d6b7af1fce9af704.JPG "點我放大")](https://trello-attachments.s3.amazonaws.com/5783d8e69b3fce2d52f94f9e/1426x1024/1d49176d14681f9448eb262aa3f1bbfb/470ca6a2d9892fa7d6b7af1fce9af704.JPG)
   - 記點紀念錄影：[點我收看](https://drive.google.com/file/d/0B_b1e3AASsaLSFZnVlJZUkUycnc/preview)

----

##採集系福音
###以下只作資料整理，非本人探點。
- https://trello.com/c/s27ofgbh

----

[gimmick:Disqus](mdwikiplay.disqus.com)
