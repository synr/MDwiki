
# YouTube 測試
- [![Alt text](https://img.youtube.com/vi/pnds1KIE-hM/0.jpg)](https://www.youtube.com/watch?v=pnds1KIE-hM "測試")
```markdown
[![Alt text](https://img.youtube.com/vi/pnds1KIE-hM/0.jpg)](https://www.youtube.com/watch?v=pnds1KIE-hM "測試")
```

## [根據官方的提示來寫](http://dynalon.github.io/mdwiki/#!gimmicks.md#Youtube)
- [](https://www.youtube.com/watch?v=TVzTnxBQq7E)
```markdown
[](https://www.youtube.com/watch?v=TVzTnxBQq7E)
```